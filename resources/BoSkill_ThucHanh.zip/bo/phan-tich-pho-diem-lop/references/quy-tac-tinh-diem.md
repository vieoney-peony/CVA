# Quy tắc tính điểm và xếp loại

## Mục lục

1. Công thức tính điểm trung bình môn
2. Ngưỡng xếp loại
3. Quy ước diễn đạt trong báo cáo

---

## 1. Công thức tính điểm trung bình môn

Điểm trung bình môn học kỳ tính theo trọng số:

```
ĐTBmhk = (tổng ĐĐGtx + 2 × ĐĐGgk + 3 × ĐĐGck) / (số ĐĐGtx + 5)
```

Trong đó:

- ĐĐGtx: điểm đánh giá thường xuyên, số lượng thay đổi theo số tiết của môn.
- ĐĐGgk: điểm đánh giá giữa kỳ, hệ số 2.
- ĐĐGck: điểm đánh giá cuối kỳ, hệ số 3.

Kết quả làm tròn đến một chữ số thập phân.

**Xử lý ô trống.** Nếu thiếu một cột ĐĐGtx, tính theo số cột thực có, mẫu số giảm tương ứng. Nếu thiếu ĐĐGgk hoặc ĐĐGck, không tính điểm trung bình cho học sinh đó và đưa vào danh sách thiếu điểm — đây là dữ liệu chưa hoàn chỉnh, không phải điểm 0.

## 2. Ngưỡng xếp loại

| Mức | Điều kiện |
|---|---|
| Tốt | ĐTB từ 8,0 trở lên |
| Khá | ĐTB từ 6,5 đến dưới 8,0 |
| Đạt | ĐTB từ 5,0 đến dưới 6,5 |
| Chưa đạt | ĐTB dưới 5,0 |

Ngưỡng trên là mặc định. Nếu trường áp dụng ngưỡng khác, sửa tại đây và tại phần `NGUONG` trong `scripts/phan_tich_diem.py`. Sửa một chỗ mà quên chỗ kia sẽ tạo ra báo cáo mâu thuẫn giữa bảng và biểu đồ.

## 3. Quy ước diễn đạt trong báo cáo

**Luôn nêu sĩ số kèm tỷ lệ.** Viết "12 trên 38 học sinh, chiếm 31,6%" thay vì chỉ "31,6%". Với lớp dưới 40 học sinh, một em thay đổi làm tỷ lệ dịch hơn 2,5 điểm phần trăm.

**Độ lệch chuẩn quan trọng ngang điểm trung bình.** Lớp trung bình 6,8 với độ lệch chuẩn 1,0 và lớp trung bình 6,8 với độ lệch chuẩn 2,1 là hai tình huống sư phạm hoàn toàn khác nhau. Khi độ lệch chuẩn vượt 1,8, phải nêu rõ lớp đang phân hóa mạnh.

**So sánh giữa các lớp phải thận trọng.** Chênh lệch điểm trung bình dưới 0,3 giữa hai lớp không đủ căn cứ kết luận lớp nào tốt hơn. Nói "tương đương". Ngoài ra hai lớp có thể khác nhau về đầu vào, không chỉ khác về giảng dạy.

**Chênh lệch giữa điểm cuối kỳ và điểm thường xuyên là tín hiệu đáng chú ý.** Điểm cuối kỳ thấp hơn điểm thường xuyên từ 2,0 trở lên cho thấy học sinh có thể gặp khó khăn trong kiểm tra tập trung, hoặc điểm thường xuyên chưa phản ánh đúng năng lực. Nêu ra để giáo viên tự đánh giá, không kết luận thay.

**Không quy kết nguyên nhân từ số liệu.** Số liệu cho biết cái gì đang xảy ra, không cho biết vì sao. Phần nguyên nhân phải do giáo viên đứng lớp nhận định.

**Không tô hồng và không bi kịch hóa.** Nêu đúng con số, kể cả khi kết quả kém.
