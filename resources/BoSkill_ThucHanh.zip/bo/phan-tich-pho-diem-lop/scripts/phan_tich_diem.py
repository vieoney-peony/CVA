#!/usr/bin/env python3
"""Phan tich pho diem lop tu bang diem Excel.

Cach dung:
    python phan_tich_diem.py BangDiem.xlsx -o ket_qua.json -b bieu_do/
"""

import argparse
import json
import os
import re
import sys
import unicodedata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

# DejaVu Sans la phong duy nhat trong moi truong hien thi du dau tieng Viet.
plt.rcParams["font.family"] = "DejaVu Sans"

NAVY = "#1E2A5A"
CAM = "#ED8804"
XAM = "#5A6070"
XAM_NHAT = "#DCE0E8"

# Nguong xep loai — phai khop voi references/quy-tac-tinh-diem.md
NGUONG = [(8.0, "Tốt"), (6.5, "Khá"), (5.0, "Đạt"), (0.0, "Chưa đạt")]
THU_TU_MUC = ["Tốt", "Khá", "Đạt", "Chưa đạt"]
MAU_MUC = {"Tốt": NAVY, "Khá": "#5A6591", "Đạt": "#C7A66B", "Chưa đạt": CAM}

MAU_PII = re.compile(r"(ho\s*va\s*ten|ho\s*ten|full\s*name|^ten$|email|dien\s*thoai|sdt|cccd|cmnd)", re.I)


def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s).strip().lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("\u0111", "d")


def nhan_dien_cot(cot_list):
    """Tra ve (danh sach cot thuong xuyen, cot giua ky, cot cuoi ky).

    Nhan dien cot diem TRUOC roi moi xet cac cot con lai, de tranh truong hop
    ten cot chua tu khoa gay nhan nham.
    """
    tx, gk, ck = [], None, None
    for c in cot_list:
        k = bo_dau(c)
        if "ck" in k or "cuoi ky" in k or "cuoi ki" in k:
            ck = ck or c
        elif "gk" in k or "giua ky" in k or "giua ki" in k:
            gk = gk or c
        elif "tx" in k or "thuong xuyen" in k:
            tx.append(c)
    return tx, gk, ck


def tim_cot_ma(df):
    for c in df.columns:
        k = bo_dau(c)
        if ("ma" in k and ("hoc sinh" in k or "hs" in k)) or k == "ma":
            return c
    return None


def tim_cot_lop(df):
    for c in df.columns:
        if bo_dau(c) in ("lop", "class") and df[c].nunique(dropna=True) <= max(10, 0.3 * len(df)):
            return c
    return None


def xep_loai(diem):
    for nguong, ten in NGUONG:
        if diem >= nguong:
            return ten
    return NGUONG[-1][1]


def tinh(df, tx, gk, ck):
    ket, thieu = [], []
    for _, r in df.iterrows():
        diem_tx = [float(r[c]) for c in tx if pd.notna(r[c])]
        co_gk = pd.notna(r[gk])
        co_ck = pd.notna(r[ck])
        if not co_gk or not co_ck or not diem_tx:
            thieu.append(str(r["_ma"]))
            continue
        tong = sum(diem_tx) + 2 * float(r[gk]) + 3 * float(r[ck])
        dtb = round(tong / (len(diem_tx) + 5), 1)
        ket.append({
            "ma": str(r["_ma"]),
            "lop": str(r["_lop"]),
            "dtb": dtb,
            "xep_loai": xep_loai(dtb),
            "tb_thuong_xuyen": round(sum(diem_tx) / len(diem_tx), 1),
            "cuoi_ky": float(r[ck]),
        })
    return ket, thieu


def thong_ke(ds):
    if not ds:
        return {}
    s = pd.Series([x["dtb"] for x in ds])
    dem = {m: sum(1 for x in ds if x["xep_loai"] == m) for m in THU_TU_MUC}
    return {
        "si_so_co_diem": len(ds),
        "trung_binh": round(float(s.mean()), 2),
        "do_lech_chuan": round(float(s.std(ddof=1)), 2) if len(ds) > 1 else 0.0,
        "thap_nhat": float(s.min()),
        "cao_nhat": float(s.max()),
        "phan_bo_xep_loai": dem,
        "ty_le_phan_tram": {m: round(100 * dem[m] / len(ds), 1) for m in THU_TU_MUC},
    }


def ve_pho_diem(ds, duong_dan):
    khoang = [(0, 5, "Dưới 5"), (5, 6.5, "5 – 6,4"), (6.5, 8, "6,5 – 7,9"), (8, 10.1, "8 – 10")]
    nhan = [k[2] for k in khoang]
    dem = [sum(1 for x in ds if k[0] <= x["dtb"] < k[1]) for k in khoang]
    mau = [CAM if i == 0 else NAVY for i in range(len(khoang))]

    hinh, truc = plt.subplots(figsize=(7.5, 4.2))
    cot = truc.bar(nhan, dem, color=mau, width=0.55)
    truc.bar_label(cot, fmt="%d", padding=4, fontsize=10, color=NAVY)
    truc.set_ylabel("Số học sinh", fontsize=10, color=NAVY)
    truc.set_title("Phổ điểm trung bình môn", fontsize=13, fontweight="bold", color=NAVY, pad=14)
    truc.set_ylim(0, max(dem) * 1.2 + 1)
    for canh in ("top", "right"):
        truc.spines[canh].set_visible(False)
    truc.set_axisbelow(True)
    truc.yaxis.grid(True, color=XAM_NHAT, linewidth=1)
    hinh.tight_layout()
    hinh.savefig(duong_dan, dpi=200, bbox_inches="tight")
    plt.close(hinh)


def ve_so_sanh_lop(theo_lop, duong_dan):
    if len(theo_lop) < 2:
        return False
    ten = list(theo_lop.keys())
    hinh, truc = plt.subplots(figsize=(max(6.5, 1.7 * len(ten) + 2), 4.4))
    day = [0.0] * len(ten)
    for m in THU_TU_MUC:
        gt = [theo_lop[l]["ty_le_phan_tram"][m] for l in ten]
        truc.bar(ten, gt, bottom=day, color=MAU_MUC[m], width=0.45, label=m)
        day = [a + b for a, b in zip(day, gt)]
    truc.set_ylim(0, 100)
    truc.set_ylabel("Tỷ lệ (%)", fontsize=10, color=NAVY)
    truc.set_title("Cơ cấu xếp loại theo lớp", fontsize=13, fontweight="bold", color=NAVY, pad=14)
    truc.legend(loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=4, frameon=False, fontsize=9)
    for canh in ("top", "right"):
        truc.spines[canh].set_visible(False)
    hinh.tight_layout()
    hinh.savefig(duong_dan, dpi=200, bbox_inches="tight")
    plt.close(hinh)
    return True


def main():
    bo = argparse.ArgumentParser(description="Phan tich pho diem lop")
    bo.add_argument("tep", help="Tep bang diem .xlsx")
    bo.add_argument("-o", "--dau_ra", default="ket_qua.json")
    bo.add_argument("-b", "--bieu_do", default="bieu_do")
    ts = bo.parse_args()

    try:
        df = pd.read_excel(ts.tep, engine="openpyxl")
    except Exception as loi:
        sys.exit(f"Khong doc duoc {ts.tep}: {loi}")
    df.columns = [str(c).strip() for c in df.columns]

    tx, gk, ck = nhan_dien_cot(df.columns)
    if not tx or gk is None or ck is None:
        sys.exit(
            "Khong nhan dien du cot diem.\n"
            f"  Thuong xuyen: {tx or 'khong tim thay'}\n"
            f"  Giua ky: {gk or 'khong tim thay'}\n"
            f"  Cuoi ky: {ck or 'khong tim thay'}\n"
            "Hay bao cho giao vien kiem tra lai tieu de cot."
        )

    cot_ma = tim_cot_ma(df)
    cot_lop = tim_cot_lop(df)
    df["_ma"] = df[cot_ma] if cot_ma else [f"HS{i+1:03d}" for i in range(len(df))]
    df["_lop"] = df[cot_lop] if cot_lop else "Toàn bộ"

    ds, thieu = tinh(df, tx, gk, ck)
    if not ds:
        sys.exit("Khong tinh duoc diem cho hoc sinh nao. Kiem tra lai du lieu.")

    theo_lop = {}
    for l in sorted({x["lop"] for x in ds}):
        theo_lop[l] = thong_ke([x for x in ds if x["lop"] == l])

    canh_bao = [
        {"ma": x["ma"], "lop": x["lop"], "chenh_lech": round(x["tb_thuong_xuyen"] - x["cuoi_ky"], 1)}
        for x in ds if x["tb_thuong_xuyen"] - x["cuoi_ky"] >= 2.0
    ]
    duoi_nguong = [{"ma": x["ma"], "lop": x["lop"], "dtb": x["dtb"]} for x in ds if x["dtb"] < 5.0]

    cot_pii = [c for c in df.columns if MAU_PII.search(bo_dau(c))]
    ket_qua = {
        "tep_nguon": os.path.basename(ts.tep),
        "cot_thuong_xuyen": tx, "cot_giua_ky": gk, "cot_cuoi_ky": ck,
        "tong_the": thong_ke(ds),
        "theo_lop": theo_lop,
        "thieu_diem": thieu,
        "duoi_nguong_dat": sorted(duoi_nguong, key=lambda x: x["dtb"]),
        "chenh_lech_cuoi_ky": sorted(canh_bao, key=lambda x: -x["chenh_lech"]),
        "cot_da_loai_vi_dinh_danh": cot_pii,
    }

    with open(ts.dau_ra, "w", encoding="utf-8") as f:
        json.dump(ket_qua, f, ensure_ascii=False, indent=2)

    os.makedirs(ts.bieu_do, exist_ok=True)
    ve_pho_diem(ds, os.path.join(ts.bieu_do, "pho_diem.png"))
    co_ss = ve_so_sanh_lop(theo_lop, os.path.join(ts.bieu_do, "so_sanh_lop.png"))

    print(f"Da ghi {ts.dau_ra}")
    print(f"  {ket_qua['tong_the']['si_so_co_diem']} hoc sinh co du diem, "
          f"trung binh {ket_qua['tong_the']['trung_binh']}, "
          f"do lech chuan {ket_qua['tong_the']['do_lech_chuan']}")
    print(f"  Cot diem: tx={len(tx)} | gk={gk} | ck={ck}")
    if cot_pii:
        print(f"  Da loai cot dinh danh khoi ket qua: {', '.join(cot_pii)}")
    if thieu:
        print(f"  CANH BAO - {len(thieu)} hoc sinh thieu diem, chua tinh: {', '.join(thieu[:8])}")
    if duoi_nguong:
        print(f"  {len(duoi_nguong)} hoc sinh duoi nguong Dat")
    if canh_bao:
        print(f"  {len(canh_bao)} hoc sinh co diem cuoi ky thap hon thuong xuyen tu 2.0")
    print(f"  Bieu do: pho_diem.png" + (", so_sanh_lop.png" if co_ss else ""))


if __name__ == "__main__":
    main()
