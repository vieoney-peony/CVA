---
name: phan-tich-pho-diem-lop
description: Tính điểm trung bình môn học kỳ theo công thức có trọng số, xếp loại học sinh, vẽ phổ điểm và lập báo cáo chất lượng lớp từ bảng điểm Excel. Dùng khi giáo viên nhắc tới phân tích phổ điểm, báo cáo chất lượng lớp, thống kê kết quả học tập, tổng hợp điểm cuối kỳ, hoặc cần biết tỷ lệ xếp loại của lớp.
---

# Phân tích phổ điểm lớp

Quy trình hai bước: chạy script tính toán → viết nhận định. Script lo phần số học, phần nhận định do Claude viết.

## Bước 1 — Chạy script

```bash
python scripts/phan_tich_diem.py <bang_diem.xlsx> -o ket_qua.json -b bieu_do/
```

Script tự động:

- Nhận diện các cột điểm thường xuyên, giữa kỳ, cuối kỳ theo tên cột.
- Tính điểm trung bình môn theo công thức trọng số tại `references/quy-tac-tinh-diem.md`.
- Xếp loại theo ngưỡng của trường, tách riêng từng lớp nếu bảng có nhiều lớp.
- Vẽ hai biểu đồ: phổ điểm dạng cột và so sánh tỷ lệ xếp loại giữa các lớp.
- Loại bỏ cột họ tên khỏi tệp kết quả.

Đọc `ket_qua.json` trước khi sang bước 2.

## Bước 2 — Viết nhận định

Đọc `references/quy-tac-tinh-diem.md`, mục "Quy ước diễn đạt", trước khi viết.

Báo cáo gồm bốn phần:

1. **Số liệu chung** — sĩ số có điểm, điểm trung bình lớp, độ lệch chuẩn, khoảng điểm.
2. **Phân bố xếp loại** — tỷ lệ từng mức, kèm biểu đồ.
3. **Nhóm cần chú ý** — danh sách mã học sinh dưới ngưỡng Đạt, và nhóm có điểm cuối kỳ thấp hơn điểm thường xuyên từ 2,0 trở lên.
4. **Nhận định và đề xuất** — do giáo viên quyết định, Claude gợi ý dựa trên số liệu.

## Khi dữ liệu không khớp giả định

Script giả định mỗi dòng là một học sinh, có ít nhất một cột điểm thường xuyên, đúng một cột giữa kỳ và đúng một cột cuối kỳ.

Gặp cấu trúc khác — bảng đã tính sẵn điểm trung bình, thang điểm khác 10, nhiều môn trong một tệp, tiêu đề gộp ô — thì dừng lại, mô tả cấu trúc thực tế và hỏi giáo viên trước khi xử lý. Không tự suy đoán cột nào là cột nào.

## Ràng buộc

Chỉ dùng thư viện có sẵn: pandas, openpyxl, matplotlib. Không có mạng.

Không đưa họ tên học sinh vào báo cáo. Dùng mã học sinh. Nếu giáo viên yêu cầu có tên, nhắc rằng nên thay tên khi nhập vào sổ thay vì để tên trong lịch sử trò chuyện.
