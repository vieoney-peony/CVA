---
name: chuan-hoa-giao-an-truong
description: Chuẩn hóa giáo án về đúng biểu mẫu bốn hoạt động của nhà trường, rà lỗi mục tiêu và bổ sung phần còn thiếu. Dùng khi giáo viên nhắc tới chuẩn hóa giáo án, sửa giáo án theo mẫu, kế hoạch bài dạy, giáo án chưa đúng mẫu, hoặc cần rà soát giáo án trước khi nộp tổ chuyên môn.
---

# Chuẩn hóa giáo án theo biểu mẫu nhà trường

Nhận giáo án ở bất kỳ định dạng nào, đưa về đúng biểu mẫu của trường, chỉ ra chỗ thiếu và chỗ sai.

## Quy trình bốn bước

### Bước 1 — Đọc và đối chiếu cấu trúc

Đọc giáo án được cung cấp. Đối chiếu với biểu mẫu trong `references/bieu-mau-giao-an.md`. Đọc tệp đó ngay ở bước này.

Lập danh sách: phần nào đã có, phần nào thiếu, phần nào có nhưng đặt sai vị trí.

### Bước 2 — Rà soát mục tiêu

Mục tiêu là phần sai nhiều nhất. Đọc `references/quy-tac-muc-tieu.md` trước khi rà.

Với mỗi mục tiêu, kiểm tra ba điều: có động từ đo được không, có nêu mức độ không, có khớp với hoạt động phía dưới không.

### Bước 3 — Chuẩn hóa và bổ sung

Viết lại giáo án theo đúng biểu mẫu. Với phần thiếu, soạn nội dung đề xuất và **đánh dấu rõ bằng cụm `[ĐỀ XUẤT BỔ SUNG]`** để giáo viên biết đâu là phần mình chưa viết.

Giữ nguyên ý đồ sư phạm của giáo viên. Không thay đổi phương pháp dạy học đã chọn, không đổi ngữ liệu, không thêm hoạt động mà giáo viên không đề cập — trừ khi biểu mẫu bắt buộc phải có.

### Bước 4 — Báo cáo rà soát

Kết thúc bằng một bảng ba cột: hạng mục, tình trạng, việc cần làm. Chỉ liệt kê hạng mục có vấn đề, không liệt kê hạng mục đã đạt.

## Khi giáo án không khớp giả định

Biểu mẫu này áp dụng cho giáo án một tiết của môn văn hóa. Gặp trường hợp khác — giáo án chủ đề nhiều tiết, giáo án hoạt động trải nghiệm, giáo án dạy học dự án — thì dừng lại, nêu rõ giáo án thuộc loại nào và hỏi giáo viên muốn giữ cấu trúc gốc hay ép về biểu mẫu này.

## Giới hạn

Skill này chuẩn hóa hình thức và rà lỗi logic. Nó không thẩm định tính đúng đắn của nội dung chuyên môn từng môn. Phần đó thuộc trách nhiệm của giáo viên và tổ chuyên môn.
