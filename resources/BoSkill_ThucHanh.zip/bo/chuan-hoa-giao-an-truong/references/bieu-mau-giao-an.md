# Biểu mẫu giáo án của nhà trường

## Mục lục

1. Phần đầu
2. Bốn hoạt động bắt buộc
3. Phần cuối
4. Quy ước trình bày

---

## 1. Phần đầu

| Hạng mục | Bắt buộc | Ghi chú |
|---|---|---|
| Tên bài dạy | Có | Kèm số tiết trong phân phối chương trình |
| Môn học, lớp | Có | |
| Thời lượng | Có | Ghi rõ số tiết, mỗi tiết 45 phút |
| Mục tiêu | Có | Chia ba nhóm, xem mục 2 dưới đây |
| Thiết bị dạy học và học liệu | Có | Liệt kê cụ thể, không ghi "máy chiếu, phấn bảng" chung chung |

Mục tiêu chia ba nhóm theo thứ tự: kiến thức, năng lực, phẩm chất.

## 2. Bốn hoạt động bắt buộc

Mỗi hoạt động phải có đủ bốn mục con: mục tiêu, nội dung, sản phẩm, tổ chức thực hiện.

| Hoạt động | Tên gọi | Thời lượng tham khảo |
|---|---|---|
| 1 | Mở đầu | 5–7 phút |
| 2 | Hình thành kiến thức mới | 18–22 phút |
| 3 | Luyện tập | 10–12 phút |
| 4 | Vận dụng | 5–8 phút |

Mục "Tổ chức thực hiện" phải viết theo bốn chuyển giao: giao nhiệm vụ, thực hiện nhiệm vụ, báo cáo thảo luận, kết luận nhận định.

## 3. Phần cuối

| Hạng mục | Bắt buộc | Ghi chú |
|---|---|---|
| Hồ sơ dạy học | Có | Phiếu học tập, rubric, đề kiểm tra ngắn nếu có |
| Rút kinh nghiệm | Không | Để trống khi soạn, ghi sau khi dạy |

## 4. Quy ước trình bày

- Đánh số hoạt động bằng chữ số Ả Rập, không dùng chữ số La Mã.
- Không viết tắt tên năng lực ở lần xuất hiện đầu tiên.
- Phiếu học tập đặt ở phần Hồ sơ dạy học, không chèn giữa hoạt động.
- Mỗi hoạt động không quá một trang A4.
