# Quy tắc rà soát mục tiêu bài dạy

## Mục lục

1. Ba lỗi thường gặp
2. Động từ dùng được theo mức độ
3. Cách sửa

---

## 1. Ba lỗi thường gặp

### Lỗi 1 — Động từ không đo được

Mục tiêu dùng các động từ chỉ trạng thái bên trong: hiểu, nắm được, biết, nhận thức được, thấy được. Không quan sát được thì không đánh giá được.

Sửa bằng cách thay bằng động từ chỉ hành vi quan sát được ở mục 2.

### Lỗi 2 — Thiếu mức độ

Mục tiêu nêu hành vi nhưng không nêu điều kiện hay chuẩn đạt. "Giải được phương trình bậc hai" chưa đủ: giải trong bao lâu, không dùng máy tính hay được dùng, đúng bao nhiêu phần trăm thì coi là đạt.

### Lỗi 3 — Mục tiêu không có hoạt động tương ứng

Mục tiêu nêu ra nhưng không hoạt động nào trong bài dẫn tới việc đó, hoặc ngược lại có hoạt động chiếm nhiều thời gian mà không mục tiêu nào nhắc tới. Đây là lỗi nặng nhất vì phá vỡ tính nhất quán của bài dạy.

Cách kiểm tra: lập bảng đối chiếu mục tiêu với hoạt động. Mỗi mục tiêu phải chỉ được ít nhất một hoạt động, mỗi hoạt động phải phục vụ ít nhất một mục tiêu.

## 2. Động từ dùng được theo mức độ

| Mức độ | Động từ dùng được |
|---|---|
| Nhận biết | nêu, liệt kê, gọi tên, chỉ ra, phát biểu |
| Thông hiểu | giải thích, mô tả, phân biệt, tóm tắt, cho ví dụ |
| Vận dụng | tính, giải, áp dụng, thực hiện, vẽ, lập |
| Vận dụng cao | phân tích, so sánh, thiết kế, đánh giá, đề xuất, phản biện |

## 3. Cách sửa

Khi phát hiện lỗi, không tự ý viết lại toàn bộ mục tiêu theo ý mình. Giữ nguyên nội dung chuyên môn mà giáo viên nhắm tới, chỉ chỉnh cách diễn đạt.

Trình bày dạng đối chiếu để giáo viên thấy rõ thay đổi:

- Bản gốc: "Học sinh hiểu được định lý Pythagore."
- Đề xuất: "Học sinh phát biểu được định lý Pythagore và tính được cạnh còn lại của tam giác vuông khi biết hai cạnh, không dùng máy tính cầm tay."

Nếu một mục tiêu sai tới mức không đoán được ý định của giáo viên, hỏi lại thay vì tự suy diễn.
