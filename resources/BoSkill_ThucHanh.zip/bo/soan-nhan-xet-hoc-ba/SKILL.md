---
name: soan-nhan-xet-hoc-ba
description: Soạn nhận xét học bạ cuối kỳ theo quy ước tổ chuyên môn, gồm nhận xét về phẩm chất, năng lực và kết quả học tập, có định hướng cải thiện cụ thể. Dùng khi giáo viên nhắc tới nhận xét học bạ, lời phê học bạ, đánh giá cuối kỳ cho học sinh, nhận xét phẩm chất năng lực, hoặc cần viết nhận xét cho cả lớp.
---

# Soạn nhận xét học bạ

Nhận xét học bạ không phải lời khen chung chung. Một nhận xét đạt yêu cầu phải giúp phụ huynh biết con mình mạnh ở đâu, yếu ở đâu, và cần làm gì tiếp theo.

## Thông tin cần có trước khi viết

Nếu giáo viên chưa cung cấp đủ, hãy hỏi trước khi viết:

- Họ tên hoặc mã học sinh, lớp, học kỳ.
- Điểm hoặc mức đạt được của môn.
- Ít nhất một quan sát cụ thể về thái độ, hành vi hoặc tiến bộ trong kỳ.

Không tự bịa quan sát. Nếu chỉ có điểm số mà không có quan sát nào, hãy nói rõ rằng nhận xét sẽ chỉ phản ánh kết quả học tập và đề nghị giáo viên bổ sung.

## Cấu trúc bắt buộc — ba phần

Mỗi nhận xét gồm đúng ba phần, viết liền thành đoạn văn, không gạch đầu dòng, độ dài 45–70 từ.

1. **Ghi nhận** — nêu một điểm mạnh cụ thể, có dẫn chứng. Không dùng lời khen trống.
2. **Chỉ ra** — nêu một điểm cần cải thiện, diễn đạt theo hướng mô tả hành vi chứ không quy kết đặc điểm cá nhân.
3. **Định hướng** — nêu một việc làm được ngay trong học kỳ tới, đủ cụ thể để phụ huynh hỗ trợ.

## Quy ước diễn đạt

- Mô tả hành vi, không quy kết bản chất. Viết "chưa hoàn thành bài tập về nhà ở 4 trên 12 tuần" thay vì "lười học".
- Không so sánh với học sinh khác, không nhắc tới thứ hạng trong lớp.
- Không dùng từ tuyệt đối: luôn luôn, không bao giờ, hoàn toàn.
- Mỗi học sinh một cách diễn đạt riêng. Nếu viết cho nhiều em, không lặp lại nguyên câu giữa các em.
- Xưng hô: gọi học sinh là "em", không gọi tên trống không.
- Với học sinh có kết quả yếu, phần Ghi nhận vẫn phải có nội dung thật. Nếu không tìm được điểm mạnh về học tập, ghi nhận điểm mạnh về thái độ hoặc sự chuyên cần.

## Điều tuyệt đối tránh

- Không suy đoán về hoàn cảnh gia đình, sức khỏe hay tâm lý của học sinh.
- Không đưa nội dung có thể khiến học sinh bị so sánh bất lợi khi phụ huynh đọc.
- Không gợi ý chẩn đoán y tế hay tâm lý dưới bất kỳ hình thức nào.

## Khi viết cho cả lớp

Nhận bảng danh sách kèm điểm và quan sát, xuất ra dạng bảng hai cột: mã học sinh và nhận xét. Giữ nguyên thứ tự danh sách đầu vào để giáo viên dễ đối chiếu.

Nếu danh sách có cột họ tên, dùng mã học sinh trong bản nháp và nhắc giáo viên tự thay tên khi nhập vào sổ, để tránh lưu tên học sinh trong lịch sử trò chuyện.
