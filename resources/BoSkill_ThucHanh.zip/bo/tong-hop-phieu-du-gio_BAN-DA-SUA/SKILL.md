---
name: tong-hop-phieu-du-gio
description: Tổng hợp phiếu dự giờ của tổ chuyên môn từ tệp Excel thành báo cáo có biểu đồ theo từng tiêu chí, kèm nhận định và đề xuất. Dùng khi giáo viên nhắc tới phiếu dự giờ, tổng hợp dự giờ, kết quả thao giảng, đánh giá tiết dạy, biên bản dự giờ, hoặc cần báo cáo sinh hoạt chuyên môn.
---

# Tổng hợp phiếu dự giờ

Quy trình hai bước: chạy script tính toán → viết nhận định. Script lo phần số học, phần nhận định do Claude viết.

## Bước 1 — Chạy script

```bash
python scripts/tong_hop.py <tep.xlsx> -o ket_qua.json -b bieu_do/
```

Script tự động nhận diện cột tiêu chí thang 1–5, loại bỏ cột chứa thông tin định danh người dự, tính trung bình và độ lệch chuẩn, rồi vẽ biểu đồ theo bảng màu của trường.

Đọc `ket_qua.json` trước khi sang bước 2. **Đối chiếu số tiêu chí trong tệp kết quả với số cột tiêu chí trong tệp Excel gốc.** Nếu lệch, báo ngay cho giáo viên, không viết báo cáo trên dữ liệu thiếu.

Nếu script cảnh báo có cột chưa nhận diện được, xem lại tiêu đề cột trong tệp gốc và hỏi giáo viên.

## Bước 2 — Viết nhận định

Đọc `references/quy-uoc-nhan-dinh.md` trước khi viết.

Báo cáo gồm bốn phần: số liệu chung, kết quả theo tiêu chí kèm biểu đồ, ý kiến góp ý đã nhóm theo chủ đề, và phần nhận định — đề xuất.

## Khi dữ liệu không khớp giả định

Script giả định mỗi dòng là một phiếu và mỗi cột tiêu chí dùng thang 1–5.

Gặp cấu trúc khác — thang điểm 10, phiếu đánh giá bằng mức chữ, nhiều tiết dạy trong một tệp, tiêu đề gộp ô — thì dừng lại, mô tả cấu trúc thực tế cho giáo viên và hỏi trước khi xử lý.

## Bảo mật

Không đưa tên người dự giờ vào báo cáo. Sinh hoạt chuyên môn cần đánh giá tiết dạy, không cần định danh người đánh giá. Phần góp ý mở phải rà bằng mắt vì tên riêng thường nằm lẫn trong câu.
