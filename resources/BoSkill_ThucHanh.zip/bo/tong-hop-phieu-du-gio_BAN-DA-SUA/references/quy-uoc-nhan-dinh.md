# Quy ước viết nhận định báo cáo dự giờ

## Mục lục

1. Ngưỡng đánh giá
2. Quy tắc diễn đạt
3. Cấu trúc phần đề xuất

---

## 1. Ngưỡng đánh giá thang 1–5

| Khoảng điểm | Kết luận |
|---|---|
| Từ 4,5 | Rất tốt |
| Từ 4,0 đến dưới 4,5 | Tốt |
| Từ 3,5 đến dưới 4,0 | Đạt |
| Từ 3,0 đến dưới 3,5 | Cần cải thiện |
| Dưới 3,0 | Yếu, bắt buộc nêu trong phần đề xuất |

## 2. Quy tắc diễn đạt

**Luôn nêu số phiếu kèm kết luận.** Viết "trung bình 3,1 trên 24 phiếu" thay vì "tiết dạy chưa tốt về phân bổ thời gian".

**Chênh lệch nhỏ không phải xu hướng.** Với dưới 30 phiếu, chênh lệch dưới 0,3 điểm giữa hai tiêu chí không đủ căn cứ xếp thứ bậc. Viết "tương đương".

**Độ lệch chuẩn quan trọng ngang trung bình.** Độ lệch chuẩn vượt 1,0 nghĩa là người dự giờ chia thành hai luồng ý kiến. Phải nêu ra, vì đó là thông tin có giá trị hơn con số trung bình.

**Nhận xét về tiết dạy, không nhận xét về người dạy.** Viết "hoạt động luyện tập chưa đủ thời lượng" thay vì "giáo viên quản lý thời gian kém".

**Trích góp ý nguyên văn.** Chỉ ẩn danh, không tổng hợp nhiều ý kiến thành một câu rồi đặt trong dấu ngoặc kép.

**Không giảm nhẹ kết quả tiêu cực.** Báo cáo dự giờ thiếu trung thực làm mất ý nghĩa của cả buổi sinh hoạt chuyên môn.

## 3. Cấu trúc phần đề xuất

M��i đề xuất phải nêu được ba yếu tố: việc cần làm, căn cứ từ số liệu, và người thực hiện.

Đề xuất không dùng được: "Cần cải thiện việc phân bổ thời gian."

Đề xuất dùng được: "Chuyển phần chữa bài tập về cuối hoạt động hình thành kiến thức để dành trọn 12 phút cho luyện tập — tiêu chí phân bổ thời gian đạt 3,1, thấp nhất trong 6 tiêu chí, và 3 trên 4 góp ý mở đều nhắc tới việc hoạt động cuối bị dồn."
