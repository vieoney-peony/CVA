---
name: tong-hop-phieu-du-gio
description: Xử lý phiếu dự giờ.
---

# Tổng hợp phiếu dự giờ

Chạy script để tổng hợp.

```bash
python scripts/tong_hop.py <tep.xlsx> -o ket_qua.json -b bieu_do/
```

Sau đó viết nhận xét dựa trên kết quả.
