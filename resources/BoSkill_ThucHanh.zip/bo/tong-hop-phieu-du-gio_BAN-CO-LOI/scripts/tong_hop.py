#!/usr/bin/env python3
"""Tong hop phieu du gio tu tep Excel.

Cach dung:
    python tong_hop.py PhieuDuGio.xlsx -o ket_qua.json -b bieu_do/
"""

import argparse
import json
import os
import re
import unicodedata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

# Doi phong cho de nhin hon
plt.rcParams["font.family"] = "DejaVu Serif Display"

NAVY = "#1E2A5A"
CAM = "#ED8804"

MAU_PII = re.compile(r"(nguoi\s*du|ho\s*va\s*ten|ho\s*ten|email|dien\s*thoai)", re.I)
MAU_SIEU_DU_LIEU = re.compile(r"(tiet|thoi\s*gian|to\s*chuyen\s*mon|ngay)", re.I)


def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s).strip().lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("\u0111", "d")


def sang_diem(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        d = float(v)
        return d if 1 <= d <= 5 else None
    return None


def la_cot_likert(chuoi):
    gt = [v for v in chuoi.tolist() if v is not None and not (isinstance(v, float) and pd.isna(v))]
    if len(gt) < 3:
        return False
    return sum(1 for v in gt if sang_diem(v) is not None) / len(gt) >= 0.8


def phan_tich(df):
    cot_pii = [c for c in df.columns if MAU_PII.search(bo_dau(c))]
    con_lai = [c for c in df.columns if c not in cot_pii]

    cot_sieu = [c for c in con_lai if MAU_SIEU_DU_LIEU.search(bo_dau(c))]

    cot_likert, cot_mo = [], []
    for c in con_lai:
        if c in cot_sieu:
            continue
        if la_cot_likert(df[c]):
            cot_likert.append(c)
        elif df[c].dropna().astype(str).str.len().mean() > 15:
            cot_mo.append(c)

    tieu_chi = []
    for c in cot_likert:
        diem = [d for d in (sang_diem(v) for v in df[c]) if d is not None]
        s = pd.Series(diem)
        tieu_chi.append({
            "tieu_chi": c,
            "so_phieu": len(diem),
            "trung_binh": round(float(s.mean()), 2),
            "do_lech_chuan": round(float(s.std(ddof=1)), 2) if len(diem) > 1 else 0.0,
        })

    y_kien = []
    for c in cot_mo:
        for v in df[c].dropna():
            t = str(v).strip()
            if len(t) > 5:
                y_kien.append(t)

    return {
        "tong_so_phieu": int(len(df)),
        "tieu_chi": tieu_chi,
        "y_kien": y_kien,
        "cot_da_loai": cot_pii,
    }


def ve_bieu_do(kq, duong_dan):
    tc = sorted(kq["tieu_chi"], key=lambda x: x["trung_binh"])
    nhan = [t["tieu_chi"] for t in tc]
    diem = [t["trung_binh"] for t in tc]
    mau = [CAM if d == min(diem) else NAVY for d in diem]

    hinh, truc = plt.subplots(figsize=(9, 0.6 * len(tc) + 1.6))
    cot = truc.barh(nhan, diem, color=mau, height=0.6)
    truc.bar_label(cot, fmt="%.2f", padding=4, fontsize=9)
    truc.set_xlim(0, 5.4)
    truc.set_xlabel("Điểm trung bình (thang 1–5)")
    truc.set_title("Kết quả dự giờ theo tiêu chí")
    for canh in ("top", "right"):
        truc.spines[canh].set_visible(False)
    hinh.tight_layout()
    hinh.savefig(duong_dan, dpi=200, bbox_inches="tight")
    plt.close(hinh)


def main():
    bo = argparse.ArgumentParser()
    bo.add_argument("tep")
    bo.add_argument("-o", "--dau_ra", default="ket_qua.json")
    bo.add_argument("-b", "--bieu_do", default="bieu_do")
    ts = bo.parse_args()

    df = pd.read_excel(ts.tep, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    kq = phan_tich(df)
    with open(ts.dau_ra, "w", encoding="utf-8") as f:
        json.dump(kq, f, ensure_ascii=False, indent=2)

    os.makedirs(ts.bieu_do, exist_ok=True)
    ve_bieu_do(kq, os.path.join(ts.bieu_do, "tieu_chi.png"))

    print(f"Da ghi {ts.dau_ra}")
    print(f"  {kq['tong_so_phieu']} phieu, {len(kq['tieu_chi'])} tieu chi")
    print(f"  Bieu do: {ts.bieu_do}/tieu_chi.png")


if __name__ == "__main__":
    main()
