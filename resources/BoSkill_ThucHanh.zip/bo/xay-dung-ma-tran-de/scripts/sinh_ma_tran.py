#!/usr/bin/env python3
"""Sinh ma tran de va ban dac ta ra tep Word tu tep cau hinh JSON.

Cach dung:
    python sinh_ma_tran.py cau_hinh.json -o MaTranDe.docx
"""

import argparse
import json
import sys
from datetime import date

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

NAVY = RGBColor(0x1E, 0x2A, 0x5A)
CAM = RGBColor(0xED, 0x88, 0x04)
XAM = RGBColor(0x5A, 0x60, 0x70)
NAVY_HEX = "1E2A5A"
XAM_NEN_HEX = "F2F4F8"
FONT = "Times New Roman"

MUC = [
    ("nhan_biet", "Nhận biết"),
    ("thong_hieu", "Thông hiểu"),
    ("van_dung", "Vận dụng"),
    ("van_dung_cao", "Vận dụng cao"),
]


# ---------------------------------------------------------------- tien ich Word
def to_mau(o, ma):
    e = OxmlElement("w:shd")
    e.set(qn("w:val"), "clear")
    e.set(qn("w:fill"), ma)
    o._tc.get_or_add_tcPr().append(e)


def dat_font(chay, co, dam=False, mau=None, nghieng=False):
    chay.font.name = FONT
    chay.font.size = Pt(co)
    chay.font.bold = dam
    chay.font.italic = nghieng
    if mau is not None:
        chay.font.color.rgb = mau
    chay._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)


def doan(tl, van_ban, co=12, dam=False, mau=None, canh=None, nghieng=False, truoc=0, sau=6):
    d = tl.add_paragraph()
    d.paragraph_format.space_before = Pt(truoc)
    d.paragraph_format.space_after = Pt(sau)
    d.paragraph_format.line_spacing = 1.25
    if canh is not None:
        d.alignment = canh
    dat_font(d.add_run(van_ban), co, dam, mau, nghieng)
    return d


def tieu_de(tl, van_ban, co=15):
    return doan(tl, van_ban, co, True, NAVY, truoc=14, sau=8)


# ---------------------------------------------------------------- kiem tra
def diem_o(o, diem_tn):
    return round(o.get("tn", 0) * diem_tn + o.get("diem_tl", 0), 3)


def kiem_tra(ch):
    loi = []
    diem_tn = ch.get("diem_moi_cau_tn", 0.25)
    tong_diem = ch.get("tong_diem", 10)

    tong = 0.0
    for cd in ch["chu_de"]:
        tong_cd = 0.0
        so_cau_cd = 0
        for khoa, ten in MUC:
            o = cd["muc_do"].get(khoa, {})
            tong_cd += diem_o(o, diem_tn)
            so_cau_cd += o.get("tn", 0) + o.get("tl", 0)
        if so_cau_cd == 0:
            loi.append(f'Chủ đề "{cd["ten"]}" không có câu hỏi nào.')
        if cd.get("so_tiet", 0) <= 1:
            vdc = cd["muc_do"].get("van_dung_cao", {})
            if vdc.get("tn", 0) + vdc.get("tl", 0) > 0:
                loi.append(f'Chủ đề "{cd["ten"]}" chỉ dạy {cd.get("so_tiet")} tiết '
                           f'nhưng có câu mức Vận dụng cao.')
        tong += tong_cd

    tong = round(tong, 3)
    if abs(tong - tong_diem) > 0.001:
        loi.append(f"Tổng điểm các ô là {tong}, khác tổng điểm toàn bài {tong_diem}. "
                   f"Chênh lệch {round(tong - tong_diem, 2)}.")

    # Sai lech ty le so voi ty le mac dinh, chi canh bao
    canh_bao = []
    if tong > 0:
        mac_dinh = ({"nhan_biet": 30, "thong_hieu": 30, "van_dung": 30, "van_dung_cao": 10}
                    if "cuối" in ch.get("loai_bai", "").lower()
                    else {"nhan_biet": 40, "thong_hieu": 30, "van_dung": 20, "van_dung_cao": 10})
        for khoa, ten in MUC:
            d = sum(diem_o(cd["muc_do"].get(khoa, {}), diem_tn) for cd in ch["chu_de"])
            tl = 100 * d / tong
            if abs(tl - mac_dinh[khoa]) > 5:
                canh_bao.append(f"Mức {ten} chiếm {tl:.1f}%, lệch quá 5 điểm phần trăm "
                                f"so với tỷ lệ tham chiếu {mac_dinh[khoa]}%.")
    return loi, canh_bao


# ---------------------------------------------------------------- dung tep
def bang_ma_tran(tl, ch):
    diem_tn = ch.get("diem_moi_cau_tn", 0.25)
    bang = tl.add_table(rows=1, cols=6)
    bang.style = "Table Grid"
    bang.alignment = WD_TABLE_ALIGNMENT.CENTER

    nhan = ["Chủ đề", "Nhận biết", "Thông hiểu", "Vận dụng", "Vận dụng cao", "Tổng điểm"]
    for o, t in zip(bang.rows[0].cells, nhan):
        to_mau(o, NAVY_HEX)
        o.paragraphs[0].text = ""
        o.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        dat_font(o.paragraphs[0].add_run(t), 10.5, True, RGBColor(0xFF, 0xFF, 0xFF))

    tong_theo_muc = {k: 0.0 for k, _ in MUC}
    tong_chung = 0.0

    for i, cd in enumerate(ch["chu_de"]):
        o_hang = bang.add_row().cells
        o_hang[0].paragraphs[0].text = ""
        dat_font(o_hang[0].paragraphs[0].add_run(f'{cd["ten"]} ({cd.get("so_tiet", "?")} tiết)'), 10.5)

        tong_cd = 0.0
        for j, (khoa, _) in enumerate(MUC, start=1):
            o = cd["muc_do"].get(khoa, {})
            d = diem_o(o, diem_tn)
            tong_cd += d
            tong_theo_muc[khoa] += d
            phan = []
            if o.get("tn"):
                phan.append(f'{o["tn"]} TN')
            if o.get("tl"):
                phan.append(f'{o["tl"]} TL')
            oo = o_hang[j]
            oo.paragraphs[0].text = ""
            oo.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            dat_font(oo.paragraphs[0].add_run(
                f'{" + ".join(phan)}\n{d:g} đ' if phan else "–"), 10.5)

        tong_chung += tong_cd
        oc = o_hang[5]
        oc.paragraphs[0].text = ""
        oc.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        dat_font(oc.paragraphs[0].add_run(f"{tong_cd:g}"), 10.5, True)

        if i % 2 == 1:
            for o in o_hang:
                to_mau(o, XAM_NEN_HEX)

    o_tong = bang.add_row().cells
    o_tong[0].paragraphs[0].text = ""
    dat_font(o_tong[0].paragraphs[0].add_run("Tổng"), 10.5, True, NAVY)
    for j, (khoa, _) in enumerate(MUC, start=1):
        d = tong_theo_muc[khoa]
        tl = 100 * d / tong_chung if tong_chung else 0
        o = o_tong[j]
        o.paragraphs[0].text = ""
        o.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        dat_font(o.paragraphs[0].add_run(f"{d:g} đ\n{tl:.0f}%"), 10.5, True, NAVY)
    o_tong[5].paragraphs[0].text = ""
    o_tong[5].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    dat_font(o_tong[5].paragraphs[0].add_run(f"{tong_chung:g}"), 10.5, True, NAVY)

    rong = [Cm(4.6), Cm(2.5), Cm(2.5), Cm(2.5), Cm(2.6), Cm(2.3)]
    for h in bang.rows:
        for o, r in zip(h.cells, rong):
            o.width = r


def phan_dac_ta(tl, ch):
    diem_tn = ch.get("diem_moi_cau_tn", 0.25)
    stt = 1
    for cd in ch["chu_de"]:
        doan(tl, cd["ten"], 12.5, True, NAVY, truoc=10, sau=4)
        for khoa, ten in MUC:
            o = cd["muc_do"].get(khoa, {})
            n_tn, n_tl = o.get("tn", 0), o.get("tl", 0)
            if n_tn + n_tl == 0:
                continue
            mo_ta = []
            if n_tn:
                mo_ta.append(f"{n_tn} câu trắc nghiệm ({n_tn * diem_tn:g} đ)")
            if n_tl:
                mo_ta.append(f'{n_tl} câu tự luận ({o.get("diem_tl", 0):g} đ)')
            d = tl.add_paragraph(style="List Bullet")
            d.paragraph_format.space_after = Pt(3)
            d.paragraph_format.line_spacing = 1.2
            dat_font(d.add_run(f"Câu {stt}"), 11.5, True)
            dat_font(d.add_run(f" — Mức {ten}: " + ", ".join(mo_ta)), 11.5)
            stt += n_tn + n_tl
        for c in cd.get("chuan_can_dat", []):
            d = tl.add_paragraph(style="List Bullet 2")
            d.paragraph_format.space_after = Pt(2)
            dat_font(d.add_run(f"Chuẩn cần đạt: {c}"), 11, nghieng=True, mau=XAM)


def main():
    bo = argparse.ArgumentParser(description="Sinh ma tran de kiem tra")
    bo.add_argument("cau_hinh")
    bo.add_argument("-o", "--dau_ra", default="MaTranDe.docx")
    ts = bo.parse_args()

    with open(ts.cau_hinh, encoding="utf-8") as f:
        ch = json.load(f)

    loi, canh_bao = kiem_tra(ch)
    if loi:
        print("KHONG SINH DUOC TEP — cau hinh co loi:", file=sys.stderr)
        for l in loi:
            print(f"  - {l}", file=sys.stderr)
        print("\nHay sua cau_hinh.json roi chay lai. Khong sua truc tiep tep Word.",
              file=sys.stderr)
        sys.exit(1)

    tl = Document()
    for m in tl.sections:
        m.left_margin = m.right_margin = Cm(2.0)
        m.top_margin = m.bottom_margin = Cm(2.0)

    doan(tl, "MA TRẬN VÀ BẢN ĐẶC TẢ ĐỀ KIỂM TRA", 16, True, NAVY,
         WD_ALIGN_PARAGRAPH.CENTER, sau=4)
    doan(tl, f'{ch["loai_bai"]} · Môn {ch["mon_hoc"]} · Lớp {ch["khoi_lop"]}', 12.5,
         mau=CAM, canh=WD_ALIGN_PARAGRAPH.CENTER, sau=2)
    doan(tl, f'Thời gian làm bài: {ch["thoi_gian_phut"]} phút · '
             f'Hình thức: {ch.get("hinh_thuc", "—")} · '
             f'Lập ngày {date.today().strftime("%d/%m/%Y")}',
         11, mau=XAM, canh=WD_ALIGN_PARAGRAPH.CENTER, sau=14)

    tieu_de(tl, "I. Ma trận đề")
    bang_ma_tran(tl, ch)
    tl.add_paragraph()

    tieu_de(tl, "II. Bản đặc tả")
    doan(tl, "Phần chuẩn cần đạt do giáo viên rà soát và chịu trách nhiệm chuyên môn.",
         11, mau=XAM, nghieng=True, sau=8)
    phan_dac_ta(tl, ch)

    tl.save(ts.dau_ra)
    print(f"Da ghi {ts.dau_ra}")
    tong_cau = sum(o.get("tn", 0) + o.get("tl", 0)
                   for cd in ch["chu_de"] for o in cd["muc_do"].values())
    print(f"  {len(ch['chu_de'])} chu de, {tong_cau} cau, tong {ch.get('tong_diem', 10)} diem")
    for c in canh_bao:
        print(f"  CANH BAO - {c}")


if __name__ == "__main__":
    main()
