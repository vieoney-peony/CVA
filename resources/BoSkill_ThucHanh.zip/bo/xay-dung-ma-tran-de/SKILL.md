---
name: xay-dung-ma-tran-de
description: Xây dựng ma trận đề và bản đặc tả đề kiểm tra định kỳ, phân bổ số câu theo chủ đề và mức độ nhận thức, kiểm tra tổng điểm rồi xuất ra tệp Word. Dùng khi giáo viên nhắc tới ma trận đề, bản đặc tả, bảng trọng số câu hỏi, xây dựng đề kiểm tra giữa kỳ hoặc cuối kỳ, hoặc cần phân bổ câu hỏi theo mức độ.
---

# Xây dựng ma trận đề kiểm tra

Quy trình ba bước: thu thập thông tin → lập tệp cấu hình → sinh tệp Word.

## Bước 1 — Thu thập thông tin

Hỏi giáo viên năm thông tin sau nếu chưa có. Hỏi gộp trong một lượt, không hỏi từng câu.

1. Môn học, khối lớp, loại bài kiểm tra (giữa kỳ hay cuối kỳ), thời gian làm bài.
2. Danh sách chủ đề cần kiểm tra, kèm số tiết đã dạy của mỗi chủ đề.
3. Hình thức: trắc nghiệm hoàn toàn, tự luận hoàn toàn, hay kết hợp. Nếu kết hợp thì tỷ lệ điểm.
4. Tỷ lệ bốn mức độ nhận thức. Nếu giáo viên không có yêu cầu riêng, dùng tỷ lệ mặc định tại `references/muc-do-nhan-thuc.md`.
5. Tổng điểm toàn bài, mặc định 10.

## Bước 2 — Lập tệp cấu hình

Đọc `references/muc-do-nhan-thuc.md` trước khi phân bổ, để nắm quy tắc làm tròn và ràng buộc.

Số tiết đã dạy là căn cứ chính để chia số câu giữa các chủ đề. Chủ đề dạy nhiều tiết hơn thì nhiều câu hơn.

Soạn tệp `cau_hinh.json` theo đúng cấu trúc mẫu tại `assets/mau_ma_tran.json`. Trước khi chạy bước 3, tự kiểm ba điều:

- Tổng điểm của tất cả các ô bằng đúng tổng điểm toàn bài.
- Không chủ đề nào có số câu bằng 0 ở cả bốn mức độ.
- Mức Vận dụng cao không rơi vào chủ đề chỉ dạy một tiết.

## Bước 3 — Sinh tệp Word

```bash
python scripts/sinh_ma_tran.py cau_hinh.json -o MaTranDe.docx
```

Script tự kiểm tra lại tổng điểm và số câu. Nếu lệch, script dừng và báo lỗi chi tiết — sửa `cau_hinh.json` rồi chạy lại, không sửa trực tiếp tệp Word.

Tệp Word gồm hai phần: ma trận đề dạng bảng và bản đặc tả liệt kê từng câu kèm chuẩn cần đạt.

## Khi thông tin không đủ

Không tự bịa danh sách chủ đề theo trí nhớ về chương trình. Nếu giáo viên không cung cấp, hãy hỏi, hoặc đề nghị giáo viên gửi phân phối chương trình.

Không tự quyết định chuẩn cần đạt của từng câu. Đây là nội dung chuyên môn thuộc thẩm quyền của giáo viên; Claude chỉ đề xuất và phải đánh dấu rõ phần đề xuất.
