# Mức độ nhận thức và quy tắc phân bổ

## Mục lục

1. Bốn mức độ
2. Tỷ lệ mặc định
3. Quy tắc làm tròn
4. Ràng buộc bắt buộc

---

## 1. Bốn mức độ

| Mức | Tên | Yêu cầu đối với học sinh |
|---|---|---|
| 1 | Nhận biết | Nhắc lại, nhận ra kiến thức đã học, không cần biến đổi |
| 2 | Thông hiểu | Diễn đạt lại theo cách khác, giải thích, phân biệt |
| 3 | Vận dụng | Áp dụng vào tình huống tương tự tình huống đã học |
| 4 | Vận dụng cao | Áp dụng vào tình huống mới, phân tích, đánh giá, thiết kế |

Ranh giới hay nhầm nhất là giữa mức 3 và mức 4. Câu hỏi chỉ đổi số liệu so với bài đã chữa vẫn là mức 3, dù trông có vẻ khó.

## 2. Tỷ lệ mặc định

Áp dụng khi giáo viên không có yêu cầu riêng.

| Loại bài | Nhận biết | Thông hiểu | Vận dụng | Vận dụng cao |
|---|---|---|---|---|
| Kiểm tra giữa kỳ | 40% | 30% | 20% | 10% |
| Kiểm tra cuối kỳ | 30% | 30% | 30% | 10% |

Tỷ lệ tính theo điểm, không theo số câu. Một câu tự luận mức Vận dụng cao có thể chiếm 2 điểm trong khi một câu trắc nghiệm mức Nhận biết chỉ 0,25 điểm.

## 3. Quy tắc làm tròn

Số câu phải là số nguyên, nên tỷ lệ điểm hiếm khi chia hết. Thứ tự ưu tiên khi làm tròn:

1. Giữ đúng tổng điểm toàn bài. Đây là ràng buộc không được vi phạm.
2. Giữ đúng tỷ lệ mức Vận dụng cao. Đây là mức dễ bị cắt xén nhất khi làm tròn.
3. Điều chỉnh ở mức Nhận biết, vì mức này có nhiều câu nhất nên chịu sai số tốt nhất.

Sai lệch tỷ lệ sau khi làm tròn không được vượt quá 5 điểm phần trăm ở bất kỳ mức nào.

## 4. Ràng buộc bắt buộc

- Mỗi chủ đề phải có ít nhất một câu. Chủ đề đã dạy mà không kiểm tra là lỗi thiết kế đề.
- Chủ đề chỉ dạy một tiết không đặt câu mức Vận dụng cao.
- Với đề trắc nghiệm, mỗi câu 0,25 điểm là mức chuẩn. Số câu trắc nghiệm nhân 0,25 phải bằng đúng phần điểm dành cho trắc nghiệm; nếu không khớp thì điều chỉnh số câu, không đổi điểm mỗi câu thành số lẻ.
- Với đề kết hợp, phần tự luận không dưới 30% tổng điểm, nếu không thì mất ý nghĩa phân hóa.
- Thời gian làm bài tham chiếu: 1 phút cho một câu trắc nghiệm mức 1–2, 1,5 phút cho mức 3–4, 8–12 phút cho một câu tự luận.
