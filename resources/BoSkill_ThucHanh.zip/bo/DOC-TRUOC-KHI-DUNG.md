# Bộ Skill kèm Tập bài thực hành

## Cách dùng

M��i thư mục dưới đây là một Skill hoàn chỉnh, đã chạy thử. Để nạp lên tài khoản:

1. Nén **chính thư mục Skill** thành tệp zip (không nén các tệp bên trong nó).
   Mở zip ra phải thấy thư mục, bên trong mới là SKILL.md.
2. Vào Settings › Features, tải tệp zip lên.
3. Mở cuộc trò chuyện mới, nêu yêu cầu theo cách nói tự nhiên, không gọi tên Skill.

## Danh mục

| Thư mục | Bài | Ghi chú |
|---|---|---|
| soan-nhan-xet-hoc-ba | 1 | Chỉ có SKILL.md |
| chuan-hoa-giao-an-truong | 2 | Có 2 tệp tham chiếu |
| phan-tich-pho-diem-lop | 3 | Có script — dùng với BangDiem_Toan10_HK1.xlsx |
| xay-dung-ma-tran-de | 4 | Có biểu mẫu và script sinh Word |
| tong-hop-phieu-du-gio_BAN-CO-LOI | 5 | **Bản có 3 lỗi** — dùng để thực hành chẩn đoán |
| tong-hop-phieu-du-gio_BAN-DA-SUA | 5 | Bản đã sửa — chỉ mở sau khi tự làm |

Trước khi nạp bản ở Bài 5, **đổi tên thư mục** về `tong-hop-phieu-du-gio` cho khớp
trường `name` trong SKILL.md. Hậu tố BAN-CO-LOI và BAN-DA-SUA chỉ để phân biệt khi lưu trữ.

## Dữ liệu mẫu

- `BangDiem_Toan10_HK1.xlsx` — 73 học sinh, 2 lớp, có 2 trường hợp thiếu điểm bắt buộc.
- `PhieuDuGio_Thang10.xlsx` — 24 phiếu, 6 tiêu chí thang 1–5, có cột định danh và cột góp ý mở.

Cả hai đều là **dữ liệu mô phỏng**, không phải dữ liệu thật. Khi áp dụng cho lớp mình,
phải thay họ tên học sinh bằng mã trước khi đưa vào Claude.

## Ràng buộc kỹ thuật

Các script chỉ dùng thư viện có sẵn: pandas, openpyxl, matplotlib, python-docx.
M�i trường thực thi không có mạng, không cài thêm gói được.
